#include "selectcctvpage.h"

#include <cstring>

#include <lib/qtmaterialtheme.h>

SelectCCTVPage::SelectCCTVPage(QWidget *parent) : QWidget(parent)
{
    QGridLayout *gridLayout = new QGridLayout;

    for(int i = 0; i < 3; i++) {
        char iconPath[25] = ":/temp/temp/parking";
        char temp[2];
        itoa(i+1, temp, 5);
        strcat(iconPath, temp);
        strcat(iconPath, ".png");

        QPushButton *pushBtn = new QPushButton;
        pushBtn->setStyleSheet("QPushButton { background-color: white; }");
        pushBtn->setFlat(true);
        pushBtn->setIcon(QIcon(iconPath));
        pushBtn->setIconSize(QSize(320, 180));

        QSignalMapper *signalMapper = new QSignalMapper;
        connect (pushBtn, SIGNAL(clicked()), signalMapper, SLOT(map())) ;

        signalMapper -> setMapping (pushBtn, i) ;

        connect (signalMapper, SIGNAL(mapped(int)), this, SLOT(showCCTV(int))) ;

        btnVector.push_back(pushBtn);

        char buttonText[] = "CCTV 0";
        strcat(buttonText, temp);

        QtMaterialRadioButton *radioButton = new QtMaterialRadioButton;
        radioButton->setText(buttonText);

        radioVector.push_back(radioButton);

        gridLayout->addWidget(btnVector[i], 0, i);
        gridLayout->addWidget(radioVector[i], 1, i);
    }

    QtMaterialIconButton *prevBtn = new QtMaterialIconButton(QtMaterialTheme::icon("image", "navigate_before"));
    prevBtn->setIconSize(QSize(60, 60));
    prevBtn->setDisabled(true);

    QtMaterialIconButton *nextBtn = new QtMaterialIconButton(QtMaterialTheme::icon("image", "navigate_next"));
    nextBtn->setIconSize(QSize(60, 60));
    nextBtn->connect(nextBtn, SIGNAL(clicked()), this, SLOT(nextPageClick()));

    QFont font("Roboto", 18, QFont::Medium);

    // Init Label
    QLabel *message = new QLabel("STEP 1. Select a Camera to indicate the entrance.");
    message->setFont(font);

    QVBoxLayout *verticalLayout = new QVBoxLayout;
    verticalLayout->addWidget(message);
    verticalLayout->addLayout(gridLayout);

    QHBoxLayout *horizontalLayout = new QHBoxLayout;
    horizontalLayout->addWidget(prevBtn);
    horizontalLayout->addLayout(verticalLayout);
    horizontalLayout->addWidget(nextBtn);

    setLayout(horizontalLayout);
}

void SelectCCTVPage::showCCTV(int num)
{
    radioVector[num]->setChecked(true);

    QString fileName("C:\\PLD\\playVideo.exe");

    QStringList commandAndParameters;
    if(num < 3) {
        commandAndParameters << "C:\\PLD\\cctv0" + QString().setNum(num + 1) +".mp4";
    } else {
        commandAndParameters << "http://http://165.194.104.50:5000/video_feed";
    }
    QProcess *process = new QProcess;
    process->start(fileName, commandAndParameters);
}

void SelectCCTVPage::nextPageClick()
{
    if(!isClick) {
        int i = 1;
        for(QtMaterialRadioButton *btn : radioVector) {
            if(btn->isChecked()) {
                isClick = true;
                emit nextPageClicked(i);
            }
            i++;
        }
    }
}
