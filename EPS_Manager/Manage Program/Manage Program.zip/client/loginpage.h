#ifndef LOGINPAGE_H
#define LOGINPAGE_H

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QStackedWidget>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrl>
#include <QDateTime>
#include <QFile>
#include <QDebug>

#include "signupwindow.h"
#include "clientwindow.h"
#include "inputspacewindow.h"
#include "customdialog.h"
#include "values.h"

#include <../components/qtmaterialflatbutton.h>
#include <../components/qtmaterialraisedbutton.h>
#include <../components/qtmaterialtextfield.h>
#include <../components/qtmaterialdialog.h>

class LogInPage : public QWidget
{
    Q_OBJECT
public:
    explicit LogInPage(QWidget *parent = nullptr);

signals:
    void logInClicked();

public slots:
    void logInBtnClick();
    void signUpBtnClick();

    void next();

    void checkReplyFinished (QNetworkReply *reply);

private:
    QtMaterialTextField *idField;
    QtMaterialTextField *pwField;

    void logIn(QString id, QString pw);
};

#endif // LOGINPAGE_H
