#include "selectdirpage.h"

#include <lib/qtmaterialtheme.h>
#include <cmath>

selectDirPage::selectDirPage(int cctvNum, QVector<QLine> lines, QWidget *parent) : QWidget(parent)
{
    this->lines = new QVector<QLine>(lines);
    cctv = cctvNum;

    clickPos = QPoint();
    setMouseTracking(true);

    strcat(iconPath, ":/temp/temp/parking");
    char temp[2];
    itoa(cctvNum, temp, 5);
    strcat(iconPath, temp);
    strcat(iconPath, ".png");

    QImage *img = new QImage();
    QPixmap *buffer = new QPixmap();

    if(img->load(iconPath)) {
        *buffer = QPixmap::fromImage(*img);
        width = buffer->rect().width();
        height = buffer->rect().height();
        *buffer = buffer->scaled(960, 540);
    } else {

    }

    painter = new QPainter(buffer);

    label = new PainterLabel;
    label->setPixmap(*buffer);
    label->resize(buffer->width(), buffer->height());
    label->connect(label, SIGNAL(Mouse_Pressed()), this, SLOT(Mouse_Pressed()));

    QtMaterialIconButton *prevBtn = new QtMaterialIconButton(QtMaterialTheme::icon("image", "navigate_before"));
    prevBtn->setIconSize(QSize(60, 60));
    prevBtn->connect(prevBtn, SIGNAL(clicked()), this, SLOT(homeBtn()));

    QtMaterialIconButton *nextBtn = new QtMaterialIconButton(QtMaterialTheme::icon("image", "navigate_next"));
    nextBtn->setIconSize(QSize(60, 60));
    nextBtn->connect(nextBtn, SIGNAL(clicked()), this, SLOT(nextBtn()));

    QFont font("Roboto", 18, QFont::Medium);

    // Init Label
    QLabel *message = new QLabel("STEP 3. Select the Direction of entry.");
    message->setFont(font);

    QVBoxLayout *verticalLayout = new QVBoxLayout;
    verticalLayout->addWidget(message);
    verticalLayout->addWidget(label);

    QHBoxLayout *horizontalLayout = new QHBoxLayout;
    horizontalLayout->addWidget(prevBtn);
    horizontalLayout->addLayout(verticalLayout);
    horizontalLayout->addWidget(nextBtn);

    setLayout(horizontalLayout);
    drawLines(painter);
}

void selectDirPage::Mouse_Pressed()
{
    clickPos = label->pos;
    if(checkInCircle(clickPos)){
        drawLines(painter);
    }
}

void selectDirPage::nextBtn()
{
    if(!isClick) {
        saveMappingFile();
        emit homePageClicked();
    }
    isClick = true;
}

void selectDirPage::homeBtn()
{
    if(!isClick) {
        emit homePageClicked();
    }
    isClick = true;
}

void selectDirPage::drawLines(QPainter *p)
{
    if (lines->size() > 0) {
        int imgDirectionSize = 60;
        QImage *img = new QImage();
        QPixmap *buffer = new QPixmap();

        if(img->load(iconPath)) {
            *buffer = QPixmap::fromImage(*img);
            *buffer = buffer->scaled(960, 540);
        } else {

        }

        QPen pen;
        pen.setColor(Qt::red);
        pen.setWidth(4);

        painter = new QPainter(buffer);
        painter->setPen(pen);
        int i = 0;
        for(QLine line : *lines) {
            double x, y;
            double m = sqrt(pow(line.p2().x()-line.p1().x(), 2) + pow(line.p1().y()-line.p2().y(), 2));
            double d = (line.p2().x() - line.p1().x()) / m;
            x = (line.p1().x() + line.p2().x())/2;
            y = (line.p1().y() + line.p2().y())/2;

            painter->drawLine(line);

            int temp = 1;
            int temp2 = 0;
            if(line.p1().y() > line.p2().y()) {
                temp = -1;
                temp2 = 180;
            }

            if(img->load(":/temp/temp/direction.png")) {
                QPoint center = img->rect().center();
                QMatrix matrix;
                matrix.translate(center.x(), center.y());
                int degree = temp2 + temp * (270 + (acos(d) * 180 / 3.14));
                if(rotate[i] == true) {
                    degree = degree + 180;
                }
                matrix.rotate(degree);
                QImage dstImg = img->transformed(matrix);
//                dstImg.scaled(imgDirectionSize, imgDirectionSize);
                QPixmap rotateImg = QPixmap();
                rotateImg = QPixmap::fromImage(dstImg);
                rotateImg = rotateImg.scaled(imgDirectionSize, imgDirectionSize);

                painter->drawPixmap(x - imgDirectionSize/2,
                                    y - imgDirectionSize/2, rotateImg );
            }
            i++;
        }
        label->setPixmap(*buffer);
    }
}

void selectDirPage::saveMappingFile()
{
//    QString homePath = QDir::homePath();
    strcat(saveFile, "C:\\PLD\\cctv");
    if(cctv < 10) {
        strcat(saveFile, "0");
    }
    char temp[2];
    itoa(cctv, temp, 5);
    strcat(saveFile, temp);
    strcat(saveFile, ".txt");
    QFile file(saveFile);
    if (file.open(QIODevice::WriteOnly | QFile::Truncate)) {
        QTextStream stream( &file );
        stream << lines->size() << endl;
        int i = 0;
        for (QLine line : *lines) {
            double a, b, c, d;
            a = line.p1().x() * width / 960;
            b = line.p1().y()* height / 540 ;
            c = line.p2().x()* width / 960 ;
            d = line.p2().y()* height / 540 ;
            stream << (int)a << "/";
            stream << (int)b << "/";
            stream << (int)c << "/";
            stream << (int)d << "/";
            if(rotate[i]) {
                stream << 1 << endl;
            } else {
                stream << 0 << endl;
            }
            i++;
        }
        file.close();
    }
}

bool selectDirPage::checkInCircle(QPoint pos)
{
    int i = 0;
    bool value = false;

    for(QLine line : *lines) {
        if(betPointToPoint(pos, line.center()) < 60) {
            rotate[i] = !rotate[i];
            value = true;
        }
        i++;
    }

    return value;
}

double selectDirPage::betPointToPoint(QPoint click, QPoint circle)
{
    double intX = abs(click.x() - circle.x());
    double intY = abs(click.y() - circle.y());

    return (double)(sqrt(pow(intX, 2) + pow(intY, 2)));
}
