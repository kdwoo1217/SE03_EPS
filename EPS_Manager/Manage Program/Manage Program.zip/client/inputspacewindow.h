#ifndef INPUTSPACEWINDOW_H
#define INPUTSPACEWINDOW_H

#include <QMainWindow>
#include <QFont>
#include <QLabel>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrl>
#include <QDateTime>
#include <QFile>
#include <QDebug>

#include "values.h"

#include "../components/qtmaterialtextfield.h"
#include "../components/qtmaterialraisedbutton.h"

namespace Ui {
class InputSpaceWindow;
}

class InputSpaceWindow : public QMainWindow
{
    Q_OBJECT

signals:
    void sendFinish();

public slots:
    void sendBtnClick();
    void updateFinished(QNetworkReply*);

public:
    explicit InputSpaceWindow(QWidget *parent = 0);
    ~InputSpaceWindow();

private:
    Ui::InputSpaceWindow *ui;

    QtMaterialTextField *spaceField;
};

#endif // INPUTSPACEWINDOW_H
