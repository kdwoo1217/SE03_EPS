#ifndef CUSTOMDIALOG_H
#define CUSTOMDIALOG_H

#include <QWidget>
#include <QLabel>
#include <QVBoxLayout>

#include "../components/qtmaterialflatbutton.h"

class CustomDialog : public QWidget
{
    Q_OBJECT
public:
    explicit CustomDialog(char* title, char* text, QWidget *parent = nullptr);
    QWidget *getWidget();
    QtMaterialFlatButton *getCloseButton();

signals:

public slots:

private:
    QWidget *dialogWidget;
    QtMaterialFlatButton *closeButton;
};

#endif // CUSTOMDIALOG_H
