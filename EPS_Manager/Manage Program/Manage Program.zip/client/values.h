#ifndef VALUES_H
#define VALUES_H

#include <QString>

class Values
{
public:
    static Values* getInstance();

    void setPID(int);
    void setNote(QString);
    void setCurrentSpace(int);
    void setIP(QString);
    int getPID();
    QString getIP();
    QString getNote();
    int getCurrentSpace();
private :
    Values() {}
    static Values* inst;
    QString ip;
    QString note;
    int currentSpace = 0;
    int id = 0;
};

#endif // VALUES_H
