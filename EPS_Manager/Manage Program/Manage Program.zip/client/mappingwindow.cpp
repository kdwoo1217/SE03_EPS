#include "mappingwindow.h"
#include "ui_mappingwindow.h"

#include <string.h>

#include <lib/qtmaterialtheme.h>

MappingWindow::MappingWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MappingWindow)
{
    ui->setupUi(this);
    ui->horizontalLayout->setAlignment(Qt::AlignCenter);
    this->setStyleSheet("QMainWindow { background: white; }");

    ui->stackedWidget->setCurrentIndex(0);

    selectPage = new SelectCCTVPage;
    ui->horizontalLayout->addWidget(selectPage);

    connect(selectPage, SIGNAL(nextPageClicked(int)), this, SLOT(secondPage(int)));
}

MappingWindow::~MappingWindow()
{
    delete ui;
}

void MappingWindow::firstPage()
{
    selectPage->isClick = false;
    ui->stackedWidget->setCurrentIndex(0);
}

void MappingWindow::secondPage(int num)
{
    DrawLinePage *page = new DrawLinePage(num);
    connect(page, SIGNAL(nextPageClicked(int, QVector<QLine>)), this,
            SLOT(thirdPage(int, QVector<QLine>)));
    connect(page, SIGNAL(homePageClicked()), this, SLOT(firstPage()));

    ui->verticalLayout->setAlignment(Qt::AlignCenter);
    ui->stackedWidget->setCurrentIndex(1);
    QLayoutItem *child;
    while ((child = ui->verticalLayout->takeAt(0)) != 0) {
        delete child;
    }
    ui->verticalLayout->addWidget(page);
}

void MappingWindow::thirdPage(int cctvNum, QVector<QLine> lines)
{
    selectDirPage *page = new selectDirPage(cctvNum, lines);
    connect(page, SIGNAL(homePageClicked()), this, SLOT(firstPage()));

    ui->verticalLayout2->setAlignment(Qt::AlignCenter);
    ui->stackedWidget->setCurrentIndex(2);
    QLayoutItem *child;
    while ((child = ui->verticalLayout2->takeAt(0)) != 0) {
        delete child;
    }
    ui->verticalLayout2->addWidget(page);
}

void MappingWindow::closeEvent(QCloseEvent *event) {
    emit closeSignal();

    event->accept();
}
