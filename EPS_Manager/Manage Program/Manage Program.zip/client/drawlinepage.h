#ifndef DRAWLINEPAGE_H
#define DRAWLINEPAGE_H

#include <QWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFile>

#include "painterlabel.h"

#include "../components/qtmaterialiconbutton.h"

class DrawLinePage : public QWidget
{
    Q_OBJECT
public:
    explicit DrawLinePage(int cctvNum, QWidget *parent = nullptr);

signals:
    void nextPageClicked(int, QVector<QLine>);
    void homePageClicked();

public slots:
    void Mouse_current_pos();
    void Mouse_Pressed();
    void nextBtnClick();
    void homeBtn();

protected:

private:
    void drawLines(QPainter *p);

    bool isClick = false;
    char iconPath[25] = {0,};
    int cctv;

    QtMaterialIconButton *nextBtn;

    PainterLabel *label;
    QPainter *painter;

    QPoint startPos;
    QPoint endPos;
    bool inDrawing;

    QVector<QLine> *lines = new QVector<QLine>();
};

#endif // DRAWLINEPAGE_H
