#ifndef FINALPAGE_H
#define FINALPAGE_H

#include <QWidget>
#include <QVBoxLayout>
#include <QProcess>
#include <QFile>

#include "mappingwindow.h"
#include "inputspacewindow.h"

#include <../components/qtmaterialflatbutton.h>
#include <../components/qtmaterialraisedbutton.h>

#include "values.h"

class FinalPage : public QWidget
{
    Q_OBJECT
public:
    explicit FinalPage(QWidget *parent = nullptr);

signals:

public slots:
    void cctv1ShowClick();
    void cctv2ShowClick();
    void cctv3ShowClick();
    void mappingClick();
    void currentCarCountClick();

private:
    bool checkMappingFile(int);
    int click = 0;
};

#endif // FINALPAGE_H
