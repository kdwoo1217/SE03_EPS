#include "clientwindow.h"
#include "ui_clientwindow.h"

#include <QLabel>

#define MAX_CCTV 3

ClientWindow::ClientWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ClientWindow)
{
    ui->setupUi(this);
    ui->verticalLayout->setAlignment(Qt::AlignCenter);

    this->setStyleSheet("QMainWindow { background: white; }");

    ui->stackedWidget->setCurrentIndex(0);

    LogInPage *logInpage = new LogInPage;
    mappingPage = new MappingPage;
    mappingPage->connect(mappingPage, SIGNAL(nextPage()), this, SLOT(logInClick()));

    ui->verticalLayout->addWidget(logInpage);
    ui->verticalLayout_2->addWidget(mappingPage);
    connect(logInpage, SIGNAL(logInClicked()), this, SLOT(logInClick()));
}

ClientWindow::~ClientWindow()
{
    delete ui;
}

void ClientWindow::logInClick()
{
    if(!checkMappingFile()) {
        mappingPage->startMappingProcess(1500);
        ui->stackedWidget->setCurrentIndex(1);
    }
    else {
        FinalPage *page = new FinalPage;
        ui->verticalLayout_3->addWidget(page);
        ui->stackedWidget->setCurrentIndex(2);
    }
}

bool ClientWindow::checkMappingFile()
{
    bool returnValue = false;

    for(int i = 1; i <= MAX_CCTV; i++) {
        char fileName[10] = {0, };
        strcat(fileName, "C:\\PLD\\cctv");
        if(i < 10) {
            strcat(fileName, "0");
        }
        char temp[2] = {0, };
        itoa(i, temp, 5);
        strcat(fileName, temp);
        strcat(fileName, ".txt");
        QFile file(fileName);
        if (file.open(QIODevice::ReadOnly)) {
            file.close();
            returnValue = true;
        }
        file.close();
    }
    return returnValue;
}
