#include "inputspacewindow.h"
#include "ui_inputspacewindow.h"

void InputSpaceWindow::sendBtnClick()
{
    if(spaceField->text().length() != 0) {
        qDebug("True");

        QNetworkAccessManager *manager =  new QNetworkAccessManager;
        connect(manager, SIGNAL(finished(QNetworkReply*)),
                    this, SLOT(updateFinished(QNetworkReply*)));

        QString url;
        url = "http://" + Values::getInstance()->getIP() + "/updateCarCount/?parkinglotID=";
        url = url + QString().setNum(Values::getInstance()->getPID()) + "&carCount=" + spaceField->text();
        QNetworkReply *reply = manager->get(QNetworkRequest(QUrl(url)));
    }
}

void InputSpaceWindow::updateFinished(QNetworkReply *reply)
{
    if(reply->error())
    {
        qDebug() << "ERROR!";
        qDebug() << reply->errorString();
    }
    else
    {
        qDebug() << reply->header(QNetworkRequest::ContentTypeHeader).toString();
        qDebug() << reply->header(QNetworkRequest::LastModifiedHeader).toDateTime().toString();;
        qDebug() << reply->header(QNetworkRequest::ContentLengthHeader).toULongLong();
        qDebug() << reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        qDebug() << reply->attribute(QNetworkRequest::HttpReasonPhraseAttribute).toString();

//        QFile *file = new QFile("C:/Qt/Dummy/downloaded.txt");
//        if(file->open(QFile::Append))
//        {
//            file->write(reply->readAll());
//            file->flush();
//            file->close();
//        }
//        delete file;
        Values::getInstance()->setCurrentSpace(spaceField->text().toInt());
        emit sendFinish();
    }

    this->close();
}

InputSpaceWindow::InputSpaceWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::InputSpaceWindow)
{
    ui->setupUi(this);
    ui->verticalLayout->setAlignment(Qt::AlignCenter);

    this->setStyleSheet("QMainWindow { background: white; }");

    spaceField = new QtMaterialTextField();
    spaceField->setLabel("Current Car");
    spaceField->setFixedWidth(220);
    spaceField->setLabelFontSize(12);

    QHBoxLayout *layout = new QHBoxLayout;
    layout->setAlignment(Qt::AlignRight);
    QtMaterialRaisedButton *send = new QtMaterialRaisedButton("Send");
    send->setHaloVisible(false);
    send->setFixedWidth(100);
    send->connect(send, SIGNAL(clicked()), this, SLOT(sendBtnClick()));
    layout->addWidget(send);

    ui->verticalLayout->addWidget(spaceField);
    ui->verticalLayout->addLayout(layout);
}

InputSpaceWindow::~InputSpaceWindow()
{
    delete ui;
}
