#ifndef SELECTDIRPAGE_H
#define SELECTDIRPAGE_H

#include <QWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFile>

#include "painterlabel.h"

#include "../components/qtmaterialiconbutton.h"

class selectDirPage : public QWidget
{
    Q_OBJECT
public:
    explicit selectDirPage(int cctvNum, QVector<QLine> lines, QWidget *parent = nullptr);

signals:
    void nextPageClicked();
    void homePageClicked();

public slots:
    void Mouse_Pressed();
    void nextBtn();
    void homeBtn();

protected:

private:
    void drawLines(QPainter *p);
    void saveMappingFile();
    bool checkInCircle(QPoint);
    double betPointToPoint(QPoint, QPoint);
    bool isClick = false;

    char iconPath[25] = {0, };
    char saveFile[45] = {0, };
    int cctv;

    int width, height;

    PainterLabel *label;
    QPainter *painter;

    QPoint clickPos;

    QVector<QLine> *lines;
    bool rotate[3] = {0, };
};

#endif // SELECTDIRPAGE_H
