#include "signupwindow.h"
#include "ui_signupwindow.h"

SignUpWindow::SignUpWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::SignUpWindow)
{
    ui->setupUi(this);
    ui->verticalLayout->setAlignment(Qt::AlignTop);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->setAlignment(Qt::AlignCenter);

    ui->verticalLayout->addLayout(layout);

    this->setStyleSheet("QMainWindow { background: white; }");

    QFont font("Roboto", 12, QFont::Medium);

    // Init Label
    QLabel *priceLabel = new QLabel("*Price");
    priceLabel->setFont(font);
    QLabel *noteLabel = new QLabel("Note");
    noteLabel->setFont(font);

    // Init TextField
    idField = new QtMaterialTextField();
    idField->setLabel("*ID");
    idField->setFixedWidth(330);
    idField->setLabelFontSize(12);
    pwField = new QtMaterialTextField();
    pwField->setLabel("*PW");
    pwField->setFixedWidth(400);
    pwField->setLabelFontSize(12);
    pwField->setEchoMode(QLineEdit::Password);
    pwCheckerField = new QtMaterialTextField();
    pwCheckerField->setLabel("*PW Check");
    pwCheckerField->setPlaceholderText("Input Same Password");
    pwCheckerField->setFixedWidth(400);
    pwCheckerField->setLabelFontSize(12);
    pwCheckerField->setEchoMode(QLineEdit::Password);
    connect(pwCheckerField, SIGNAL(textChanged(const QString &)), this, SLOT(pwCheckerChangeListener()));
    nameField = new QtMaterialTextField();
    nameField->setLabel("*Parking Lot Name");
    nameField->setFixedWidth(400);
    nameField->setLabelFontSize(12);
    locationField = new QtMaterialTextField();
    locationField->setLabel("*Location");
    locationField->setFixedWidth(400);
    locationField->setLabelFontSize(12);
    totalSpaceField = new QtMaterialTextField();
    totalSpaceField->setLabel("*Total Space");
    totalSpaceField->setFixedWidth(400);
    totalSpaceField->setLabelFontSize(12);

    priceCheckBox = new QtMaterialCheckBox();
    priceCheckBox->setText("Free");
    connect(priceCheckBox, SIGNAL(toggled(bool)), this, SLOT(hidePriceEdit(bool)));

    // Init Price Text Editor
    QtMaterialScrollBar *priceVerticalScrollBar = new QtMaterialScrollBar();
    QtMaterialScrollBar *priceHorizontalScrollBar = new QtMaterialScrollBar();
    priceEdit = new QTextEdit;
    priceEdit->setLineWrapMode(QTextEdit::NoWrap);
    priceEdit->update();
    priceEdit->setFixedWidth(400);
    priceEdit->setMaximumHeight(150);
    priceEdit->setFont(font);

    priceEdit->setVerticalScrollBar(priceVerticalScrollBar);
    priceEdit->setHorizontalScrollBar(priceHorizontalScrollBar);
    priceVerticalScrollBar->setHideOnMouseOut(false);
    priceHorizontalScrollBar->setHideOnMouseOut(false);
    priceHorizontalScrollBar->setOrientation(Qt::Horizontal);

    // Init Note Text Editor
    QtMaterialScrollBar *noteVerticalScrollBar = new QtMaterialScrollBar();
    QtMaterialScrollBar *noteHorizontalScrollBar = new QtMaterialScrollBar();
    noteEdit = new QTextEdit;
    noteEdit->setLineWrapMode(QTextEdit::NoWrap);
    noteEdit->update();
    noteEdit->setFixedWidth(400);
//    noteEdit->setMaximumHeight(200);
    noteEdit->setFont(font);

    noteEdit->setVerticalScrollBar(priceVerticalScrollBar);
    noteEdit->setHorizontalScrollBar(priceHorizontalScrollBar);
    noteVerticalScrollBar->setHideOnMouseOut(false);
    noteHorizontalScrollBar->setHideOnMouseOut(false);
    noteHorizontalScrollBar->setOrientation(Qt::Horizontal);

    // Init Button
    QtMaterialRaisedButton *signUpBtn = new QtMaterialRaisedButton("Sign Up");
    signUpBtn->setHaloVisible(false);
    signUpBtn->setFixedWidth(100);
    signUpBtn->connect(signUpBtn, SIGNAL(clicked()), this, SLOT(signUpBtnClick()));

    QtMaterialFlatButton *idCheckBtn = new QtMaterialFlatButton("ID Check");
    idCheckBtn->setHaloVisible(false);
    idCheckBtn->setFixedWidth(100);
    idCheckBtn->connect(idCheckBtn, SIGNAL(clicked()), this, SLOT(isExistIdCheckClick()));

    //
    QHBoxLayout *hBoxLayout = new QHBoxLayout();
    hBoxLayout->setAlignment(Qt::AlignRight);
    hBoxLayout->addWidget(signUpBtn);
    //
    QHBoxLayout *hBoxLayout2 = new QHBoxLayout();
    hBoxLayout2->setAlignment(Qt::AlignLeft);
    hBoxLayout2->addWidget(idField);
    hBoxLayout2->addWidget(idCheckBtn);

    layout->addLayout(hBoxLayout2);
    layout->addWidget(pwField);
    layout->addWidget(pwCheckerField);
    layout->addWidget(nameField);
    layout->addWidget(locationField);
    layout->addWidget(totalSpaceField);
    layout->addWidget(priceLabel);
    layout->addWidget(priceCheckBox);
    layout->addWidget(priceEdit);
    layout->addWidget(noteLabel);
    layout->addWidget(noteEdit);
    layout->addLayout(hBoxLayout);
}

void SignUpWindow::pwCheckerChangeListener() {
    if(pwField->text().compare(pwCheckerField->text()) != 0) {
        QColor qColor("#ff0000");
        pwCheckerField->setInkColor(qColor);
        pwCheckerField->setLabelColor(qColor);
        pwCheckerField->setInputLineColor(qColor);
        pwCheckerField->update();
    }
    else {
        QColor qColor("#00BCD4");
        pwCheckerField->setInkColor(qColor);
        pwCheckerField->setLabelColor(pwField->labelColor());
        pwCheckerField->setInputLineColor(qColor);
        pwCheckerField->update();
    }
    qDebug("TextChange");
}

void SignUpWindow::hidePriceEdit(bool checked) {
    if(checked) {
        priceEdit->hide();
    }
    else {
        priceEdit->show();
    }
    qDebug("CheckBox Change");
}

void SignUpWindow::isExistIdCheckClick()
{
    if(idField->text().length() != 0) {
        qDebug("True");

        QNetworkAccessManager *manager =  new QNetworkAccessManager;
        connect(manager, SIGNAL(finished(QNetworkReply*)),
                    this, SLOT(checkReplyFinished(QNetworkReply*)));

        QString url;
        url = "http://" + Values::getInstance()->getIP() + "/isExistID/?id=";
        url = url + idField->text();
        QNetworkReply *reply = manager->get(QNetworkRequest(QUrl(url)));

//        QEventLoop loop;
//        connect(reply, SIGNAL(finished()), &loop, SLOT(quit()));
//        connect(reply, SIGNAL(error(QNetworkReply::NetworkError)), &loop, SLOT(quit()));
//        loop.exec();

//        bts = reply->readAll();
//        QString str(bts);

//        delete reply;

//        this->close();
    }
    else {
        QVBoxLayout *layout = new QVBoxLayout;
        QWidget *canvas = new QWidget;
        canvas->setStyleSheet("QWidget { background: white; }");

        canvas->setLayout(layout);
        canvas->setMaximumHeight(300);

        QtMaterialDialog *dialog = new QtMaterialDialog();

        dialog->setParent(this);

        QWidget *dialogWidget = new QWidget;
        QVBoxLayout *dialogWidgetLayout = new QVBoxLayout;
        dialogWidget->setLayout(dialogWidgetLayout);

        QLabel *textTitle = new QLabel("ERROR");
        QFont fontTitle("Roboto", 15, QFont::Medium);
        fontTitle.setCapitalization(QFont::AllUppercase);
        textTitle->setFont(fontTitle);

        QLabel *textDescription = new QLabel("Input ID Field.");
        QFont fontDescription("Roboto", 10, QFont::Medium);
        textDescription->setFont(fontDescription);
        textDescription->setFixedHeight(50);
        textDescription->setAlignment(Qt::AlignTop);

        QtMaterialFlatButton *closeButton = new QtMaterialFlatButton("Close");
        closeButton->setHaloVisible(false);
        closeButton->setFixedWidth(100);

        dialogWidgetLayout->addWidget(textTitle);
        dialogWidgetLayout->addWidget(textDescription);
        dialogWidgetLayout->addWidget(closeButton);
        dialogWidgetLayout->setAlignment(closeButton, Qt::AlignBottom | Qt::AlignCenter);

        QVBoxLayout *dialogLayout = new QVBoxLayout;
        dialog->setWindowLayout(dialogLayout);

        dialogLayout->addWidget(dialogWidget);

        dialog->show();
        dialog->showDialog();
        connect(closeButton, SIGNAL(pressed()), dialog, SLOT(hideDialog()));

        qDebug("False");
    }
}

void SignUpWindow::signUpBtnClick() {
    if(idCheck == true) {
        if(idField->text().length() != 0 && pwField->text().length() != 0 && pwCheckerField->text().length() != 0
                && nameField->text().length() != 0 && locationField->text().length() != 0
                && totalSpaceField->text().length() != 0
                && ((!priceCheckBox->isChecked() && priceEdit->toPlainText().length() != 0) || priceCheckBox->isChecked())) {
            qDebug("True");            

            getGeocodeToPoint(locationField->text());
        }
        else {
            QVBoxLayout *layout = new QVBoxLayout;
            QWidget *canvas = new QWidget;
            canvas->setStyleSheet("QWidget { background: white; }");

            canvas->setLayout(layout);
            canvas->setMaximumHeight(300);

            QtMaterialDialog *dialog = new QtMaterialDialog();

            dialog->setParent(this);

            QWidget *dialogWidget = new QWidget;
            QVBoxLayout *dialogWidgetLayout = new QVBoxLayout;
            dialogWidget->setLayout(dialogWidgetLayout);

            QLabel *textTitle = new QLabel("ERROR");
            QFont fontTitle("Roboto", 15, QFont::Medium);
            fontTitle.setCapitalization(QFont::AllUppercase);
            textTitle->setFont(fontTitle);

            QLabel *textDescription = new QLabel("Check about All Text Field");
            QFont fontDescription("Roboto", 10, QFont::Medium);
            textDescription->setFont(fontDescription);
            textDescription->setFixedHeight(50);
            textDescription->setAlignment(Qt::AlignTop);

            QtMaterialFlatButton *closeButton = new QtMaterialFlatButton("Close");
            closeButton->setHaloVisible(false);
            closeButton->setFixedWidth(100);

            dialogWidgetLayout->addWidget(textTitle);
            dialogWidgetLayout->addWidget(textDescription);
            dialogWidgetLayout->addWidget(closeButton);
            dialogWidgetLayout->setAlignment(closeButton, Qt::AlignBottom | Qt::AlignCenter);

            QVBoxLayout *dialogLayout = new QVBoxLayout;
            dialog->setWindowLayout(dialogLayout);

            dialogLayout->addWidget(dialogWidget);

            dialog->show();
            dialog->showDialog();
            connect(closeButton, SIGNAL(pressed()), dialog, SLOT(hideDialog()));

            qDebug("False");
        }
    } else {
        QVBoxLayout *layout = new QVBoxLayout;
        QWidget *canvas = new QWidget;
        canvas->setStyleSheet("QWidget { background: white; }");

        canvas->setLayout(layout);
        canvas->setMaximumHeight(300);

        QtMaterialDialog *dialog = new QtMaterialDialog();

        dialog->setParent(this);

        QWidget *dialogWidget = new QWidget;
        QVBoxLayout *dialogWidgetLayout = new QVBoxLayout;
        dialogWidget->setLayout(dialogWidgetLayout);

        QLabel *textTitle = new QLabel("Check ID");
        QFont fontTitle("Roboto", 15, QFont::Medium);
        fontTitle.setCapitalization(QFont::AllUppercase);
        textTitle->setFont(fontTitle);

        QLabel *textDescription = new QLabel("Please Check Your ID");
        QFont fontDescription("Roboto", 10, QFont::Medium);
        textDescription->setFont(fontDescription);
        textDescription->setFixedHeight(50);
        textDescription->setAlignment(Qt::AlignTop);

        QtMaterialFlatButton *closeButton = new QtMaterialFlatButton("Close");
        closeButton->setHaloVisible(false);
        closeButton->setFixedWidth(100);

        dialogWidgetLayout->addWidget(textTitle);
        dialogWidgetLayout->addWidget(textDescription);
        dialogWidgetLayout->addWidget(closeButton);
        dialogWidgetLayout->setAlignment(closeButton, Qt::AlignBottom | Qt::AlignCenter);

        QVBoxLayout *dialogLayout = new QVBoxLayout;
        dialog->setWindowLayout(dialogLayout);

        dialogLayout->addWidget(dialogWidget);

        dialog->show();
        dialog->showDialog();
        connect(closeButton, SIGNAL(pressed()), dialog, SLOT(hideDialog()));

        qDebug("False");
    }
}

void SignUpWindow::replyFinished (QNetworkReply *reply)
{
    if(reply->error())
    {
        qDebug() << "ERROR!";
        qDebug() << reply->errorString();
    }
    else
    {
        qDebug() << reply->header(QNetworkRequest::ContentTypeHeader).toString();
        qDebug() << reply->header(QNetworkRequest::LastModifiedHeader).toDateTime().toString();;
        qDebug() << reply->header(QNetworkRequest::ContentLengthHeader).toULongLong();
        qDebug() << reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        qDebug() << reply->attribute(QNetworkRequest::HttpReasonPhraseAttribute).toString();

//        QFile *file = new QFile("C:/Qt/Dummy/downloaded.txt");
//        if(file->open(QFile::Append))
//        {
//            file->write(reply->readAll());
//            file->flush();
//            file->close();
//        }
//        delete file;
        bts = reply->readAll();
        reply->deleteLater();
    }

    this->close();
}

void SignUpWindow::checkReplyFinished(QNetworkReply *reply)
{
    if(reply->error())
    {
        qDebug() << "ERROR!";
        qDebug() << reply->errorString();
    }
    else
    {
        qDebug() << reply->header(QNetworkRequest::ContentTypeHeader).toString();
        qDebug() << reply->header(QNetworkRequest::LastModifiedHeader).toDateTime().toString();;
        qDebug() << reply->header(QNetworkRequest::ContentLengthHeader).toULongLong();
        qDebug() << reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        qDebug() << reply->attribute(QNetworkRequest::HttpReasonPhraseAttribute).toString();

//        QFile *file = new QFile("C:/Qt/Dummy/downloaded.txt");
//        if(file->open(QFile::Append))
//        {
//            file->write(reply->readAll());
//            file->flush();
//            file->close();
//        }
//        delete file;
        QByteArray idCheck = reply->readAll();
        if(idCheck.toInt() == 1) {
            this->idCheck = false;
            QVBoxLayout *layout = new QVBoxLayout;
            QWidget *canvas = new QWidget;
            canvas->setStyleSheet("QWidget { background: white; }");

            canvas->setLayout(layout);
            canvas->setMaximumHeight(300);

            QtMaterialDialog *dialog = new QtMaterialDialog();

            dialog->setParent(this);

            QWidget *dialogWidget = new QWidget;
            QVBoxLayout *dialogWidgetLayout = new QVBoxLayout;
            dialogWidget->setLayout(dialogWidgetLayout);

            QLabel *textTitle = new QLabel("ID Check");
            QFont fontTitle("Roboto", 15, QFont::Medium);
            fontTitle.setCapitalization(QFont::AllUppercase);
            textTitle->setFont(fontTitle);

            QLabel *textDescription = new QLabel("This ID already Exist");
            QFont fontDescription("Roboto", 10, QFont::Medium);
            textDescription->setFont(fontDescription);
            textDescription->setFixedHeight(50);
            textDescription->setAlignment(Qt::AlignTop);

            QtMaterialFlatButton *closeButton = new QtMaterialFlatButton("Close");
            closeButton->setHaloVisible(false);
            closeButton->setFixedWidth(100);

            dialogWidgetLayout->addWidget(textTitle);
            dialogWidgetLayout->addWidget(textDescription);
            dialogWidgetLayout->addWidget(closeButton);
            dialogWidgetLayout->setAlignment(closeButton, Qt::AlignBottom | Qt::AlignCenter);

            QVBoxLayout *dialogLayout = new QVBoxLayout;
            dialog->setWindowLayout(dialogLayout);

            dialogLayout->addWidget(dialogWidget);

            dialog->show();
            dialog->showDialog();
            connect(closeButton, SIGNAL(pressed()), dialog, SLOT(hideDialog()));

            qDebug("False");
        } else {
            this->idCheck = true;
            QVBoxLayout *layout = new QVBoxLayout;
            QWidget *canvas = new QWidget;
            canvas->setStyleSheet("QWidget { background: white; }");

            canvas->setLayout(layout);
            canvas->setMaximumHeight(300);

            QtMaterialDialog *dialog = new QtMaterialDialog();

            dialog->setParent(this);

            QWidget *dialogWidget = new QWidget;
            QVBoxLayout *dialogWidgetLayout = new QVBoxLayout;
            dialogWidget->setLayout(dialogWidgetLayout);

            QLabel *textTitle = new QLabel("ID Check");
            QFont fontTitle("Roboto", 15, QFont::Medium);
            fontTitle.setCapitalization(QFont::AllUppercase);
            textTitle->setFont(fontTitle);

            QLabel *textDescription = new QLabel("This ID Possible to Use");
            QFont fontDescription("Roboto", 10, QFont::Medium);
            textDescription->setFont(fontDescription);
            textDescription->setFixedHeight(50);
            textDescription->setAlignment(Qt::AlignTop);

            QtMaterialFlatButton *closeButton = new QtMaterialFlatButton("Close");
            closeButton->setHaloVisible(false);
            closeButton->setFixedWidth(100);

            dialogWidgetLayout->addWidget(textTitle);
            dialogWidgetLayout->addWidget(textDescription);
            dialogWidgetLayout->addWidget(closeButton);
            dialogWidgetLayout->setAlignment(closeButton, Qt::AlignBottom | Qt::AlignCenter);

            QVBoxLayout *dialogLayout = new QVBoxLayout;
            dialog->setWindowLayout(dialogLayout);

            dialogLayout->addWidget(dialogWidget);

            dialog->show();
            dialog->showDialog();
            connect(closeButton, SIGNAL(pressed()), dialog, SLOT(hideDialog()));

            qDebug("False");
        }
        reply->deleteLater();
    }
}

void SignUpWindow::geoReplyFinished(QNetworkReply *reply)
{
    if(reply->error())
    {
        qDebug() << "ERROR!";
        qDebug() << reply->errorString();
    }
    else
    {
        qDebug() << reply->header(QNetworkRequest::ContentTypeHeader).toString();
        qDebug() << reply->header(QNetworkRequest::LastModifiedHeader).toDateTime().toString();;
        qDebug() << reply->header(QNetworkRequest::ContentLengthHeader).toULongLong();
        qDebug() << reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        qDebug() << reply->attribute(QNetworkRequest::HttpReasonPhraseAttribute).toString();

        QByteArray result = reply->readAll();
        ////////////////////////// Json Parsing
        QJsonDocument jsonResponse = QJsonDocument::fromJson(result);
        QJsonObject jsonObject = jsonResponse.object();
        QJsonArray jsonArray = jsonObject["results"].toArray();
        foreach(const QJsonValue & value, jsonArray) {
            QJsonObject obj = value.toObject();
            jsonObject = obj["geometry"].toObject();
        }
        QJsonObject jsonObject2 = jsonObject["location"].toObject();

        float lat = jsonObject2["lat"].toDouble();
        float lng = jsonObject2["lng"].toDouble();

        latitude.setNum(lat);
        longtituge.setNum(lng);

        QNetworkAccessManager *manager =  new QNetworkAccessManager;
        connect(manager, SIGNAL(finished(QNetworkReply*)),
                    this, SLOT(replyFinished(QNetworkReply*)));

        QString url;
        QString isPrice, note;
        if(priceCheckBox->isChecked()) {
            isPrice = QString("1");
            note = noteEdit->toPlainText();
        } else {
            isPrice = QString("0");
            note = priceEdit->toPlainText() + noteEdit->toPlainText();
        }

        url = "http://" + Values::getInstance()->getIP() + "/signUp/?id=" + idField->text() + "&password=" + pwField->text()
                + "&name=" + nameField->text() + "&x=" + latitude + "&y=" + longtituge
                + "&locationCode=" + "1" + "&totalSpace=" + totalSpaceField->text() + "&isFree=" + isPrice
                + "&note=" + note;

        QNetworkReply *reply = manager->get(QNetworkRequest(QUrl(url)));
    }
}

void SignUpWindow::getGeocodeToPoint(QString location)
{
    QNetworkAccessManager *manager =  new QNetworkAccessManager;
    connect(manager, SIGNAL(finished(QNetworkReply*)),
                this, SLOT(geoReplyFinished(QNetworkReply*)));

    location.replace(" ", "+");

    QString url;
    url = "https://maps.googleapis.com/maps/api/geocode/json?address=" + location + "&AlzaSyASNFtR7klj8nPesvU3b_fXQfWALrixhY";

    QNetworkReply *reply = manager->get(QNetworkRequest(QUrl(url)));
}

SignUpWindow::~SignUpWindow()
{
    delete ui;
}
