#include "finalpage.h"

FinalPage::FinalPage(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *vLayout = new QVBoxLayout;
    vLayout->setAlignment(Qt::AlignRight|Qt::AlignTop);
    setLayout(vLayout);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->setAlignment(Qt::AlignCenter);
    layout->setMargin(100);

    QtMaterialRaisedButton *cctv01Button = new QtMaterialRaisedButton("CCTV 01");
    cctv01Button->setHaloVisible(false);
    cctv01Button->setFixedWidth(150);
    cctv01Button->setFixedHeight(50);
    cctv01Button->connect(cctv01Button, SIGNAL(clicked()), this, SLOT(cctv1ShowClick()));
    QtMaterialRaisedButton *cctv02Button = new QtMaterialRaisedButton("CCTV 02");
    cctv02Button->setHaloVisible(false);
    cctv02Button->setFixedWidth(150);
    cctv02Button->setFixedHeight(50);
    cctv02Button->connect(cctv02Button, SIGNAL(clicked()), this, SLOT(cctv2ShowClick()));
    QtMaterialRaisedButton *cctv03Button = new QtMaterialRaisedButton("CCTV 03");
    cctv03Button->setHaloVisible(false);
    cctv03Button->setFixedWidth(150);
    cctv03Button->setFixedHeight(50);
    cctv03Button->connect(cctv03Button, SIGNAL(clicked()), this, SLOT(cctv3ShowClick()));

    layout->addWidget(cctv01Button);
    layout->addWidget(cctv02Button);
    layout->addWidget(cctv03Button);

    QtMaterialRaisedButton *mappingButton = new QtMaterialRaisedButton("Mapping");
    mappingButton->setHaloVisible(false);
    mappingButton->setFixedWidth(150);
    mappingButton->setFixedHeight(50);
    mappingButton->connect(mappingButton, SIGNAL(clicked()), this, SLOT(mappingClick()));
    QtMaterialRaisedButton *noteEditButton = new QtMaterialRaisedButton("Note Edit");
    noteEditButton->setHaloVisible(false);
    noteEditButton->setFixedWidth(150);
    noteEditButton->setFixedHeight(50);
    noteEditButton->connect(noteEditButton, SIGNAL(clicked()), this, SLOT(cctv1ShowClick()));
    QtMaterialRaisedButton *currentSpaceButton = new QtMaterialRaisedButton("Count Edit");
    currentSpaceButton->setHaloVisible(false);
    currentSpaceButton->setFixedWidth(150);
    currentSpaceButton->setFixedHeight(50);
    currentSpaceButton->connect(currentSpaceButton, SIGNAL(clicked()), this, SLOT(currentCarCountClick()));
    layout->addWidget(mappingButton);
    layout->addWidget(noteEditButton);
    layout->addWidget(currentSpaceButton);

    vLayout->addLayout(layout);

    for(int i = 1; i <= 3; i++) {
        if(checkMappingFile(i)){
            QString fileName("C:\\PLD\\DPLopenCV.exe");

            switch (i) {
            case 1:
                cctv1ShowClick();
                break;
            case 2:
                cctv2ShowClick();
                break;
            case 3:
                cctv3ShowClick();
                break;
            default:
                break;
            }

            QStringList commandAndParameters;
            commandAndParameters << Values::getInstance()->getIP();
            commandAndParameters << QString().setNum(Values::getInstance()->getPID());
            commandAndParameters << QString().setNum(Values::getInstance()->getCurrentSpace());
            if(i < 3) {
                commandAndParameters << "C:\\\\PLD\\\\cctv0" + QString().setNum(i) + ".mp4";
            } else {
                commandAndParameters << "http://165.194.104.50:5000/video_feed";
            }
            commandAndParameters << "C:\\\\PLD\\\\cctv0" + QString().setNum(i) + ".txt";
            QProcess *process = new QProcess;
            process->start(fileName, commandAndParameters);
        }
    }
}

void FinalPage::mappingClick() {
    MappingWindow *window = new MappingWindow;
    window->show();
}

void FinalPage::currentCarCountClick() {
    InputSpaceWindow *window = new InputSpaceWindow;
    window->show();
}


void FinalPage::cctv1ShowClick() {
    QString fileName("C:\\PLD\\playVideo.exe");

    QStringList commandAndParameters;
    commandAndParameters << "C:\\PLD\\cctv0" + QString().setNum(1) +".mp4";
    commandAndParameters << "http://192.168.0.82:5000/video_feed";
    QProcess *process = new QProcess;
    process->start(fileName, commandAndParameters);
}

void FinalPage::cctv2ShowClick() {
    QString fileName("C:\\PLD\\playVideo.exe");

    QStringList commandAndParameters;
    commandAndParameters << "C:\\PLD\\cctv0" + QString().setNum(2) +".mp4";
    commandAndParameters << "http://192.168.0.82:5000/video_feed";
    QProcess *process = new QProcess;
    process->start(fileName, commandAndParameters);
}

void FinalPage::cctv3ShowClick() {
    QString fileName("C:\\PLD\\playVideo.exe");

    QStringList commandAndParameters;
    commandAndParameters << "http://192.168.0.82:5000/video_feed";
    QProcess *process = new QProcess;
    process->start(fileName, commandAndParameters);
}

bool FinalPage::checkMappingFile(int cctvNum)
{
    bool returnValue = false;

    char fileName[10] = {0, };
    strcat(fileName, "C:\\PLD\\cctv");
    if(cctvNum < 10) {
        strcat(fileName, "0");
    }
    char temp[2] = {0, };
    itoa(cctvNum, temp, 5);
    strcat(fileName, temp);
    strcat(fileName, ".txt");
    QFile file(fileName);
    if (file.open(QIODevice::ReadOnly)) {
        file.close();
        returnValue = true;
    }
    file.close();

    return returnValue;
}
