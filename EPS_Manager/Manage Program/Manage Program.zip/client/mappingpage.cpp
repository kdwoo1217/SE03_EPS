#include "mappingpage.h"
#include "ui_mappingpage.h"

MappingPage::MappingPage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MappingPage)
{
    ui->setupUi(this);
    ui->verticalLayout->setAlignment(Qt::AlignCenter);
    this->setStyleSheet("QMainWindow { background: white; }");

    QFont font("Roboto", 20, QFont::Medium);

    // Init Label
    QLabel *textLabel = new QLabel("Not Exist Mapping File\nPlease follow Mapping Process");
    textLabel->setFixedHeight(200);
    textLabel->setAlignment(Qt::AlignCenter);
    textLabel->setFont(font);

    QtMaterialCircularProgress *circleProgress = new QtMaterialCircularProgress;
    circleProgress->setFixedHeight(100);

    ui->verticalLayout->addWidget(textLabel);
    ui->verticalLayout->addWidget(circleProgress);
}

void MappingPage::startMappingProcess(int delayTime)
{
    QTimer *timer = new QTimer;
    timer->setSingleShot(true);

    connect(timer, SIGNAL(timeout()), this, SLOT(showMappingWindow()));

    timer->start(delayTime);
}

MappingPage::~MappingPage()
{
    delete ui;
}

void MappingPage::showMappingWindow()
{
    MappingWindow *w = new MappingWindow();
    w->connect(w, SIGNAL(closeSignal()), this, SLOT(getCloseSignal()));
    w->show();
}

void MappingPage::getCloseSignal()
{
    if(true) {
        emit nextPage();
        close();
    }
}
