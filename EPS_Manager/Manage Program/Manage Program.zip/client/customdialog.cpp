#include "customdialog.h"

CustomDialog::CustomDialog(char* title, char* text, QWidget *parent) : QWidget(parent)
{
    dialogWidget = new QWidget;
    QVBoxLayout *dialogWidgetLayout = new QVBoxLayout;
    dialogWidget->setLayout(dialogWidgetLayout);

    QLabel *textTitle = new QLabel(title);
    QFont fontTitle("Roboto", 15, QFont::Medium);
    fontTitle.setCapitalization(QFont::AllUppercase);
    textTitle->setFont(fontTitle);

    QLabel *textDescription = new QLabel(text);
    QFont fontDescription("Roboto", 10, QFont::Medium);
    textDescription->setFont(fontDescription);
    textDescription->setFixedHeight(50);
    textDescription->setAlignment(Qt::AlignTop);

    closeButton = new QtMaterialFlatButton("Close");
    closeButton->setHaloVisible(false);
    closeButton->setFixedWidth(100);

    dialogWidgetLayout->addWidget(textTitle);
    dialogWidgetLayout->addWidget(textDescription);
    dialogWidgetLayout->addWidget(closeButton);
    dialogWidgetLayout->setAlignment(closeButton, Qt::AlignBottom | Qt::AlignCenter);
}

QWidget* CustomDialog::getWidget() {
    return this->dialogWidget;
}

QtMaterialFlatButton* CustomDialog::getCloseButton() {
    return this->closeButton;
}
