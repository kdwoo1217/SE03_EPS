#include "clientwindow.h"
#include "values.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    Values::getInstance()->setIP("10.210.130.220:5000");
    QApplication a(argc, argv);
    ClientWindow w;
    w.show();

    return a.exec();
}
