#ifndef MAPPINGPAGE_H
#define MAPPINGPAGE_H

#include <QWidget>
#include <QtWidgets>
#include <QLabel>
#include <QTime>

#include "mappingwindow.h"

#include "../components/qtmaterialcircularprogress.h"

namespace Ui {
class MappingPage;
}

class MappingPage : public QWidget
{
    Q_OBJECT

public:
    explicit MappingPage(QWidget *parent = 0);
    void startMappingProcess(int delayTime);

    ~MappingPage();

signals:
    void nextPage();

private slots:
    void showMappingWindow();
    void getCloseSignal();

private:
    Ui::MappingPage *ui;

};

#endif // MAPPINGPAGE_H
