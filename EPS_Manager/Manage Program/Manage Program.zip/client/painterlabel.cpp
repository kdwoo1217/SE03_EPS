#include "painterlabel.h"

PainterLabel::PainterLabel(QLabel *parent) : QLabel(parent)
{

}

void PainterLabel::mouseMoveEvent(QMouseEvent *e)
{
    this->pos = e->pos();
//    this->x = e->x();
//    this->y = e->y();
    emit Mouse_Pos();
}

void PainterLabel::mousePressEvent(QMouseEvent *e)
{
    this->pos = e->pos();
    emit Mouse_Pressed();
}
