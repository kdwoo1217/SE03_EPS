#ifndef MAPPINGWINDOW_H
#define MAPPINGWINDOW_H

#include <QMainWindow>
#include <QCloseEvent>

#include "drawlinepage.h"
#include "selectcctvpage.h"
#include "selectdirpage.h"

namespace Ui {
class MappingWindow;
}

class MappingWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MappingWindow(QWidget *parent = 0);
    ~MappingWindow();

signals:
    void closeSignal();

public slots:
    void firstPage();
    void secondPage(int num);
    void thirdPage(int, QVector<QLine>);

private:
    Ui::MappingWindow *ui;
    SelectCCTVPage *selectPage;

    void closeEvent(QCloseEvent *event);
};

#endif // MAPPINGWINDOW_H
