#include "values.h"

Values* Values::inst = nullptr;

Values* Values::getInstance()
{
    if (inst == nullptr)
        inst = new Values();

    return inst;
}

void Values::setPID(int id)
{
    this->id = id;
}

void Values::setNote(QString note)
{
    this->note = note;
}

void Values::setCurrentSpace(int space)
{
    this->currentSpace = space;
}

void Values::setIP(QString ip)
{
    this->ip = ip;
}

int Values::getPID()
{
    return this->id;
}

QString Values::getIP()
{
    return this->ip;
}

QString Values::getNote()
{
    return this->note;
}

int Values::getCurrentSpace()
{
    return this->currentSpace;
}
