#ifndef SELECTCCTVPAGE_H
#define SELECTCCTVPAGE_H

#include <QWidget>
#include <QIcon>
#include <QLabel>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QPushButton>
#include <QSignalMapper>
#include <QProcess>

#include <vector>

#include "selectcctvpage.h"

#include "../components/qtmaterialiconbutton.h"
#include "../components/qtmaterialradiobutton.h"

class SelectCCTVPage : public QWidget
{
    Q_OBJECT
public:
    explicit SelectCCTVPage(QWidget *parent = nullptr);

    bool isClick = false;

signals:
    void nextPageClicked(int num);

public slots:
    void showCCTV(int num);
    void nextPageClick();

private:
    std::vector<QPushButton*> btnVector;
    std::vector<QtMaterialRadioButton*> radioVector;

};

#endif // SELECTCCTVPAGE_H
