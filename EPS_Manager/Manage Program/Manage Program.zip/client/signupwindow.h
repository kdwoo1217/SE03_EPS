#ifndef SIGNUPWINDOW_H
#define SIGNUPWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <QTextEdit>
#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrl>
#include <QDateTime>
#include <QFile>
#include <QDebug>

#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>

#include <../components/qtmaterialtextfield.h>
#include <../components/qtmaterialcheckbox.h>
#include <../components/qtmaterialscrollbar.h>
#include <../components/qtmaterialraisedbutton.h>
#include <../components/qtmaterialflatbutton.h>
#include <../components/qtmaterialdialog.h>

#include "values.h"
namespace Ui {
class SignUpWindow;
}

class SignUpWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit SignUpWindow(QWidget *parent = 0);
    ~SignUpWindow();

public slots:
    void pwCheckerChangeListener();
    void hidePriceEdit(bool checked);
    void isExistIdCheckClick();
    void signUpBtnClick();
    void replyFinished (QNetworkReply *reply);
    void checkReplyFinished (QNetworkReply *reply);
    void geoReplyFinished (QNetworkReply *reply);

private:
    QByteArray bts;

    Ui::SignUpWindow *ui;
    QtMaterialTextField *idField;
    QtMaterialTextField *pwField;
    QtMaterialTextField *pwCheckerField;
    QtMaterialTextField *nameField;
    QtMaterialTextField *locationField;
    QtMaterialTextField *totalSpaceField;

    QtMaterialCheckBox *priceCheckBox;

    QTextEdit *priceEdit;
    QTextEdit *noteEdit;

    void getGeocodeToPoint(QString);

    QString latitude, longtituge;
    bool idCheck = false;
};

#endif // SIGNUPWINDOW_H
