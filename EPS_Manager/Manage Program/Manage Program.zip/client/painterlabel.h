#ifndef PAINTERLABEL_H
#define PAINTERLABEL_H

#include <QLabel>
#include <QtWidgets>
#include <QMouseEvent>
#include <QDebug>

class PainterLabel : public QLabel
{
    Q_OBJECT
public:
    explicit PainterLabel(QLabel *parent = nullptr);

    void mouseMoveEvent(QMouseEvent *e);
    void mousePressEvent(QMouseEvent *e);

    QPoint pos;
    int x, y;

signals:
    void Mouse_Pressed();
    void Mouse_Pos();

public slots:

private:
};

#endif // PAINTERLABEL_H
