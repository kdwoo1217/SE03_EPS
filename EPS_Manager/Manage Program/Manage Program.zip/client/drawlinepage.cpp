#include "drawlinepage.h"

#include <lib/qtmaterialtheme.h>
#include <cmath>

DrawLinePage::DrawLinePage(int cctvNum, QWidget *parent) : QWidget(parent)
{
    cctv = cctvNum;

    startPos = QPoint();
    endPos = QPoint();
    inDrawing = false;
    setMouseTracking(true);

    strcat(iconPath, ":/temp/temp/parking");
    char temp[2];
    itoa(cctvNum, temp, 5);
    strcat(iconPath, temp);
    strcat(iconPath, ".png");

    QImage *img = new QImage();
    QPixmap *buffer = new QPixmap();

    if(img->load(iconPath)) {
        *buffer = QPixmap::fromImage(*img);
        *buffer = buffer->scaled(960, 540);
    } else {

    }

    painter = new QPainter(buffer);
//    drawLines(painter)

    label = new PainterLabel;
    label->setPixmap(*buffer);
    label->resize(buffer->width(), buffer->height());
    label->connect(label, SIGNAL(Mouse_Pos()), this, SLOT(Mouse_current_pos()));
    label->connect(label, SIGNAL(Mouse_Pressed()), this, SLOT(Mouse_Pressed()));

    QtMaterialIconButton *prevBtn = new QtMaterialIconButton(QtMaterialTheme::icon("image", "navigate_before"));
    prevBtn->setIconSize(QSize(60, 60));
    prevBtn->connect(prevBtn, SIGNAL(clicked()), this, SLOT(homeBtn()));

    nextBtn = new QtMaterialIconButton(QtMaterialTheme::icon("image", "navigate_next"));
    nextBtn->setIconSize(QSize(60, 60));
    nextBtn->setDisabled(true);
    nextBtn->connect(nextBtn, SIGNAL(clicked()), this, SLOT(nextBtnClick()));

    QFont font("Roboto", 18, QFont::Medium);

    // Init Label
    QLabel *message = new QLabel("STEP 2. Click the Points across the entrance.");
    message->setFont(font);

    QVBoxLayout *verticalLayout = new QVBoxLayout;
    verticalLayout->addWidget(message);
    verticalLayout->addWidget(label);

    QHBoxLayout *horizontalLayout = new QHBoxLayout;
    horizontalLayout->addWidget(prevBtn);
    horizontalLayout->addLayout(verticalLayout);
    horizontalLayout->addWidget(nextBtn);

    setLayout(horizontalLayout);
}

void DrawLinePage::Mouse_current_pos()
{
    if (inDrawing) {
        endPos = label->pos;
    }
}

void DrawLinePage::Mouse_Pressed()
{
    if (!inDrawing) {
        startPos = label->pos;
    }
    else {
        endPos = label->pos;

        if(endPos.x() < startPos.x()) {
            QPoint temp = endPos;
            endPos = startPos;
            startPos = temp;
        }

        QLine line = QLine(startPos, endPos);
        if(lines->size() < 10) {
            lines->append(line);
        }

        drawLines(painter);
    }

    inDrawing = !inDrawing;
}

void DrawLinePage::nextBtnClick()
{
    if(lines->size() > 0) {
        if(!isClick) {
            emit nextPageClicked(cctv, *lines);
        }
        isClick = true;
    }
}

void DrawLinePage::homeBtn()
{
    if(!isClick) {
        emit homePageClicked();
    }
    isClick = true;
}

void DrawLinePage::drawLines(QPainter *p)
{
    if (lines->size() > 0) {
        nextBtn->setDisabled(false);

        int imgDirectionSize = 80;
        QImage *img = new QImage();
        QPixmap *buffer = new QPixmap();
        QPixmap *imgDirection = new QPixmap();

        if(img->load(iconPath)) {
            *buffer = QPixmap::fromImage(*img);
            *buffer = buffer->scaled(960, 540);
        } else {

        }

        QPen pen;
        pen.setColor(Qt::red);
        pen.setWidth(4);

        painter = new QPainter(buffer);
        painter->setPen(pen);
        for(QLine line : *lines) {
            painter->drawLine(line);
        }
        label->setPixmap(*buffer);
    }

    p->drawLines(*lines);
}
