#include "loginpage.h"

LogInPage::LogInPage(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *layout = new QVBoxLayout;
    layout->setAlignment(Qt::AlignCenter);
    setLayout(layout);

    // Init TextField
    idField = new QtMaterialTextField();
    pwField = new QtMaterialTextField();
    idField->setLabel("ID");
    idField->setFixedWidth(400);
    pwField->setLabel("PW");
    pwField->setFixedWidth(400);
    pwField->setEchoMode(QLineEdit::Password);

    // Init Button
    QtMaterialRaisedButton *logInBtn = new QtMaterialRaisedButton("Log In");
    logInBtn->setHaloVisible(false);
    logInBtn->setFixedWidth(100);
    logInBtn->connect(logInBtn, SIGNAL(clicked()), this, SLOT(logInBtnClick()));
    QtMaterialFlatButton *signUpBtn = new QtMaterialFlatButton("Sign Up");
    signUpBtn->setHaloVisible(false);
    signUpBtn->setFixedWidth(100);
    signUpBtn->connect(signUpBtn, SIGNAL(clicked()), this, SLOT(signUpBtnClick()));

    //
    QHBoxLayout *hBoxLayout = new QHBoxLayout();
    hBoxLayout->setAlignment(Qt::AlignRight);
    hBoxLayout->addWidget(signUpBtn);
    hBoxLayout->addWidget(logInBtn);

    layout->addWidget(idField);
    layout->addWidget(pwField);
    layout->addLayout(hBoxLayout);
}

void LogInPage::logInBtnClick() {
    if(idField->text().length() != 0 && pwField->text().length() != 0) {
        logIn(idField->text(), pwField->text());
        qDebug("True");
    }
    else {
        QVBoxLayout *layout = new QVBoxLayout;
        QWidget *canvas = new QWidget;
        canvas->setStyleSheet("QWidget { background: white; }");

        canvas->setLayout(layout);
        canvas->setMaximumHeight(300);

        QtMaterialDialog *dialog = new QtMaterialDialog();
        dialog->setParent(window());

        CustomDialog *custom = new CustomDialog("ERROR", "Check Your ID and PW");
        QWidget *dialogWidget = custom->getWidget();

        QVBoxLayout *dialogLayout = new QVBoxLayout;
        dialog->setWindowLayout(dialogLayout);

        dialogLayout->addWidget(dialogWidget);

        dialog->show();
        dialog->showDialog();
        connect(custom->getCloseButton(), SIGNAL(pressed()), dialog, SLOT(hideDialog()));
        qDebug("False");
    }
}

void LogInPage::signUpBtnClick() {
    SignUpWindow *w = new SignUpWindow();
    w->show();
}

void LogInPage::next()
{
    emit logInClicked();
}

void LogInPage::checkReplyFinished(QNetworkReply *reply)
{
    if(reply->error())
    {
        qDebug() << "ERROR!";
        qDebug() << reply->errorString();
    }
    else
    {
        qDebug() << reply->header(QNetworkRequest::ContentTypeHeader).toString();
        qDebug() << reply->header(QNetworkRequest::LastModifiedHeader).toDateTime().toString();;
        qDebug() << reply->header(QNetworkRequest::ContentLengthHeader).toULongLong();
        qDebug() << reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        qDebug() << reply->attribute(QNetworkRequest::HttpReasonPhraseAttribute).toString();

//        QFile *file = new QFile("C:/Qt/Dummy/downloaded.txt");
//        if(file->open(QFile::Append))
//        {
//            file->write(reply->readAll());
//            file->flush();
//            file->close();
//        }
//        delete file;
        QByteArray idCheck = reply->readAll();
        QJsonDocument jsonResponse = QJsonDocument::fromJson(idCheck);
        QJsonObject jsonObject = jsonResponse.object();
        int id = jsonObject["parkinglotID"].toInt();
        QString note = jsonObject["note"].toString();

        if(id != 0) {
            //////////////////// Here!!!!!!
            Values::getInstance()->setPID(id);
            Values::getInstance()->setNote(note);

            InputSpaceWindow *window = new InputSpaceWindow;
            window->connect(window, SIGNAL(sendFinish()), this, SLOT(next()));
            window->show();
        } else {
            QVBoxLayout *layout = new QVBoxLayout;
            QWidget *canvas = new QWidget;
            canvas->setStyleSheet("QWidget { background: white; }");

            canvas->setLayout(layout);
            canvas->setMaximumHeight(300);

            QtMaterialDialog *dialog = new QtMaterialDialog();

            dialog->setParent(this);

            QWidget *dialogWidget = new QWidget;
            QVBoxLayout *dialogWidgetLayout = new QVBoxLayout;
            dialogWidget->setLayout(dialogWidgetLayout);

            QLabel *textTitle = new QLabel("ERROR");
            QFont fontTitle("Roboto", 15, QFont::Medium);
            fontTitle.setCapitalization(QFont::AllUppercase);
            textTitle->setFont(fontTitle);

            QLabel *textDescription = new QLabel("Check Your ID & PW");
            QFont fontDescription("Roboto", 10, QFont::Medium);
            textDescription->setFont(fontDescription);
            textDescription->setFixedHeight(50);
            textDescription->setAlignment(Qt::AlignTop);

            QtMaterialFlatButton *closeButton = new QtMaterialFlatButton("Close");
            closeButton->setHaloVisible(false);
            closeButton->setFixedWidth(100);

            dialogWidgetLayout->addWidget(textTitle);
            dialogWidgetLayout->addWidget(textDescription);
            dialogWidgetLayout->addWidget(closeButton);
            dialogWidgetLayout->setAlignment(closeButton, Qt::AlignBottom | Qt::AlignCenter);

            QVBoxLayout *dialogLayout = new QVBoxLayout;
            dialog->setWindowLayout(dialogLayout);

            dialogLayout->addWidget(dialogWidget);

            dialog->show();
            dialog->showDialog();
            connect(closeButton, SIGNAL(pressed()), dialog, SLOT(hideDialog()));

            qDebug("False");
        }
        reply->deleteLater();
    }
}

void LogInPage::logIn(QString id, QString pw) {
    if(id.length() != 0 && pw.length() != 0) {
        // Check ID & PW
        if(idField->text().length() != 0 && pwField->text().length() != 0) {
            qDebug("True");

            QNetworkAccessManager *manager =  new QNetworkAccessManager;
            connect(manager, SIGNAL(finished(QNetworkReply*)),
                        this, SLOT(checkReplyFinished(QNetworkReply*)));

            QString url;
            url = "http://" + Values::getInstance()->getIP() +"/signIn/?id=";
            url = url + idField->text() + "&password=" + pwField->text();
            QNetworkReply *reply = manager->get(QNetworkRequest(QUrl(url)));
        }
    }
}
